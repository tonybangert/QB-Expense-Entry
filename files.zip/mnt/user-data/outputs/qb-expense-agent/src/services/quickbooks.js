// src/services/quickbooks.js
// QuickBooks Online API client — handles OAuth, token management, and expense CRUD

const { QB_CONFIG, endpoints, queries } = require('../../config/quickbooks');
const TokenStore = require('../utils/token-store');
const logger = require('../utils/logger');

class QuickBooksService {
  constructor() {
    this.tokenStore = new TokenStore();
    this.companyId = process.env.QB_COMPANY_ID;
  }

  // ─────────────────────────────────────────────
  // OAuth 2.0 Flow
  // ─────────────────────────────────────────────

  /**
   * Generate the authorization URL to redirect the user to Intuit
   * This is Step 1 of the OAuth flow
   */
  getAuthorizationUrl(state = 'default') {
    const params = new URLSearchParams({
      client_id: QB_CONFIG.clientId,
      scope: QB_CONFIG.scopes.join(' '),
      redirect_uri: QB_CONFIG.redirectUri,
      response_type: 'code',
      state: state,
    });
    return `${QB_CONFIG.oauth.authorizationEndpoint}?${params.toString()}`;
  }

  /**
   * Exchange authorization code for access + refresh tokens
   * This is Step 2 — called from the OAuth callback route
   */
  async exchangeCodeForTokens(authorizationCode, realmId) {
    const credentials = Buffer.from(
      `${QB_CONFIG.clientId}:${QB_CONFIG.clientSecret}`
    ).toString('base64');

    const response = await fetch(QB_CONFIG.oauth.tokenEndpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json',
        'Authorization': `Basic ${credentials}`,
      },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        code: authorizationCode,
        redirect_uri: QB_CONFIG.redirectUri,
      }).toString(),
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Token exchange failed: ${response.status} — ${error}`);
    }

    const tokenData = await response.json();

    // Store tokens securely with metadata
    await this.tokenStore.save({
      accessToken: tokenData.access_token,
      refreshToken: tokenData.refresh_token,
      accessTokenExpiresAt: Date.now() + (tokenData.expires_in * 1000),
      refreshTokenExpiresAt: Date.now() + (QB_CONFIG.refreshTokenLifetime * 1000),
      realmId: realmId,
      tokenType: tokenData.token_type,
    });

    this.companyId = realmId;
    logger.info(`QuickBooks connected successfully. Company ID: ${realmId}`);

    return tokenData;
  }

  /**
   * Refresh the access token using the refresh token
   * Called automatically when access token expires
   */
  async refreshAccessToken() {
    const tokens = await this.tokenStore.load();
    if (!tokens || !tokens.refreshToken) {
      throw new Error('No refresh token available. Re-authorize at /api/auth/connect');
    }

    const credentials = Buffer.from(
      `${QB_CONFIG.clientId}:${QB_CONFIG.clientSecret}`
    ).toString('base64');

    const response = await fetch(QB_CONFIG.oauth.tokenEndpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json',
        'Authorization': `Basic ${credentials}`,
      },
      body: new URLSearchParams({
        grant_type: 'refresh_token',
        refresh_token: tokens.refreshToken,
      }).toString(),
    });

    if (!response.ok) {
      const error = await response.text();
      logger.error(`Token refresh failed: ${error}`);
      throw new Error('Token refresh failed. Re-authorize at /api/auth/connect');
    }

    const tokenData = await response.json();

    // Update stored tokens (QB issues a new refresh token each time)
    await this.tokenStore.save({
      ...tokens,
      accessToken: tokenData.access_token,
      refreshToken: tokenData.refresh_token,
      accessTokenExpiresAt: Date.now() + (tokenData.expires_in * 1000),
      refreshTokenExpiresAt: Date.now() + (QB_CONFIG.refreshTokenLifetime * 1000),
    });

    logger.info('QuickBooks access token refreshed successfully');
    return tokenData.access_token;
  }

  /**
   * Get a valid access token, refreshing if needed
   */
  async getValidToken() {
    const tokens = await this.tokenStore.load();
    if (!tokens) throw new Error('Not connected to QuickBooks');

    // Refresh if token expires within 5 minutes
    if (Date.now() > tokens.accessTokenExpiresAt - 300000) {
      return await this.refreshAccessToken();
    }

    return tokens.accessToken;
  }

  // ─────────────────────────────────────────────
  // API Request Helper
  // ─────────────────────────────────────────────

  /**
   * Make an authenticated request to the QuickBooks API
   */
  async apiRequest(method, endpoint, body = null) {
    const token = await this.getValidToken();
    const url = `${QB_CONFIG.apiBaseUrl}${endpoint}?minorversion=${QB_CONFIG.minorVersion}`;

    const options = {
      method,
      headers: {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
    };

    if (body) {
      options.body = JSON.stringify(body);
    }

    const response = await fetch(url, options);
    const data = await response.json();

    if (!response.ok) {
      logger.error('QB API Error:', { status: response.status, body: data });
      throw new Error(`QB API Error ${response.status}: ${JSON.stringify(data)}`);
    }

    return data;
  }

  /**
   * Execute a QuickBooks query (SQL-like syntax)
   */
  async query(queryString) {
    const companyId = await this.getCompanyId();
    const endpoint = endpoints.query(companyId);
    const token = await this.getValidToken();

    const url = `${QB_CONFIG.apiBaseUrl}${endpoint}?query=${encodeURIComponent(queryString)}&minorversion=${QB_CONFIG.minorVersion}`;

    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/json',
      },
    });

    const data = await response.json();
    if (!response.ok) throw new Error(`Query failed: ${JSON.stringify(data)}`);

    return data.QueryResponse;
  }

  async getCompanyId() {
    if (this.companyId) return this.companyId;
    const tokens = await this.tokenStore.load();
    if (tokens?.realmId) {
      this.companyId = tokens.realmId;
      return this.companyId;
    }
    throw new Error('Company ID not available. Connect QuickBooks first.');
  }

  // ─────────────────────────────────────────────
  // Expense (Purchase) Operations
  // ─────────────────────────────────────────────

  /**
   * Create an expense in QuickBooks from extracted receipt data
   *
   * @param {Object} expenseData - Structured receipt data
   * @param {string} expenseData.vendorName - Vendor/store name
   * @param {string} expenseData.date - Transaction date (YYYY-MM-DD)
   * @param {number} expenseData.totalAmount - Total amount
   * @param {string} expenseData.paymentMethod - cash, credit_card, check
   * @param {Array}  expenseData.lineItems - Individual items/categories
   * @param {string} expenseData.description - Receipt description
   */
  async createExpense(expenseData) {
    const companyId = await this.getCompanyId();

    // Resolve vendor (find existing or create new)
    const vendorRef = await this.resolveVendor(expenseData.vendorName);

    // Resolve payment account
    const accountRef = await this.resolvePaymentAccount(expenseData.paymentMethod);

    // Map payment type
    const paymentTypeMap = {
      'cash': 'Cash',
      'credit_card': 'CreditCard',
      'check': 'Check',
      'debit': 'Cash',
    };

    // Build line items
    const lines = await this.buildLineItems(expenseData.lineItems, expenseData.totalAmount);

    const purchase = {
      PaymentType: paymentTypeMap[expenseData.paymentMethod] || 'Cash',
      AccountRef: accountRef,
      EntityRef: vendorRef,
      TxnDate: expenseData.date,
      TotalAmt: expenseData.totalAmount,
      Line: lines,
      PrivateNote: `Auto-entered by PL Expense Agent | ${expenseData.description || ''}`.trim(),
    };

    const result = await this.apiRequest(
      'POST',
      endpoints.createPurchase(companyId),
      purchase
    );

    logger.info(`Expense created in QB: Purchase ID ${result.Purchase.Id}`);
    return result.Purchase;
  }

  /**
   * Find an existing vendor or create a new one
   */
  async resolveVendor(vendorName) {
    try {
      const result = await this.query(queries.vendorByName(vendorName));
      if (result.Vendor && result.Vendor.length > 0) {
        const vendor = result.Vendor[0];
        return { value: vendor.Id, name: vendor.DisplayName };
      }
    } catch (e) {
      logger.warn(`Vendor lookup failed for "${vendorName}": ${e.message}`);
    }

    // Create new vendor
    const companyId = await this.getCompanyId();
    const newVendor = await this.apiRequest(
      'POST',
      endpoints.createVendor(companyId),
      { DisplayName: vendorName }
    );

    logger.info(`Created new vendor: ${vendorName} (ID: ${newVendor.Vendor.Id})`);
    return { value: newVendor.Vendor.Id, name: newVendor.Vendor.DisplayName };
  }

  /**
   * Resolve the payment account based on payment method
   */
  async resolvePaymentAccount(paymentMethod) {
    // TODO: Make this configurable — map payment methods to specific QB accounts
    // For now, return a placeholder that should be configured in .env
    const accountMappings = {
      'cash': { value: process.env.QB_CASH_ACCOUNT_ID || '1', name: 'Checking' },
      'credit_card': { value: process.env.QB_CC_ACCOUNT_ID || '1', name: 'Credit Card' },
      'check': { value: process.env.QB_CHECK_ACCOUNT_ID || '1', name: 'Checking' },
      'debit': { value: process.env.QB_DEBIT_ACCOUNT_ID || '1', name: 'Checking' },
    };

    return accountMappings[paymentMethod] || accountMappings['cash'];
  }

  /**
   * Build QB line items from extracted receipt data
   */
  async buildLineItems(lineItems, totalAmount) {
    if (!lineItems || lineItems.length === 0) {
      // Single line item for the full amount
      return [{
        Amount: totalAmount,
        DetailType: 'AccountBasedExpenseLineDetail',
        AccountBasedExpenseLineDetail: {
          AccountRef: { value: process.env.QB_DEFAULT_EXPENSE_ACCOUNT_ID || '1' },
        },
        Description: 'Receipt expense',
      }];
    }

    // Map each extracted line item to a QB line
    return lineItems.map(item => ({
      Amount: item.amount,
      DetailType: 'AccountBasedExpenseLineDetail',
      AccountBasedExpenseLineDetail: {
        AccountRef: {
          value: item.accountId || process.env.QB_DEFAULT_EXPENSE_ACCOUNT_ID || '1',
          name: item.category || 'Uncategorized Expense',
        },
      },
      Description: item.description || '',
    }));
  }

  // ─────────────────────────────────────────────
  // Utility Methods
  // ─────────────────────────────────────────────

  /**
   * Get all expense accounts from the chart of accounts
   * Used to populate category dropdowns and map AI categories
   */
  async getExpenseAccounts() {
    return await this.query(queries.allExpenseAccounts);
  }

  /**
   * Get all vendors
   */
  async getVendors() {
    return await this.query(queries.allVendors);
  }

  /**
   * Test the connection by fetching company info
   */
  async testConnection() {
    const companyId = await this.getCompanyId();
    const result = await this.apiRequest(
      'GET',
      endpoints.companyInfo(companyId)
    );
    return result.CompanyInfo;
  }

  /**
   * Check if we have a valid, active connection
   */
  async isConnected() {
    try {
      const tokens = await this.tokenStore.load();
      if (!tokens) return false;

      // Check if refresh token is still valid
      if (Date.now() > tokens.refreshTokenExpiresAt) return false;

      return true;
    } catch {
      return false;
    }
  }
}

module.exports = new QuickBooksService();
