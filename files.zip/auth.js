// src/routes/auth.js
// OAuth 2.0 routes for QuickBooks authorization flow

const express = require('express');
const router = express.Router();
const qbService = require('../services/quickbooks');
const logger = require('../utils/logger');

/**
 * GET /api/auth/connect
 * Initiates the OAuth flow — redirects user to Intuit login
 */
router.get('/connect', (req, res) => {
  const state = `qb_${Date.now()}`; // CSRF protection
  const authUrl = qbService.getAuthorizationUrl(state);

  logger.info('Initiating QuickBooks OAuth flow');
  res.redirect(authUrl);
});

/**
 * GET /api/auth/callback
 * OAuth callback — Intuit redirects here after user authorizes
 * URL will contain: ?code=AUTH_CODE&state=STATE&realmId=COMPANY_ID
 */
router.get('/callback', async (req, res) => {
  const { code, state, realmId } = req.query;

  if (!code || !realmId) {
    logger.error('OAuth callback missing code or realmId', { query: req.query });
    return res.status(400).json({
      error: 'Authorization failed',
      message: 'Missing authorization code or company ID from Intuit',
    });
  }

  try {
    // Exchange the authorization code for tokens
    await qbService.exchangeCodeForTokens(code, realmId);

    // Verify the connection works
    const companyInfo = await qbService.testConnection();

    logger.info('QuickBooks OAuth completed', {
      company: companyInfo.CompanyName,
      realmId,
    });

    res.json({
      success: true,
      message: 'QuickBooks connected successfully!',
      company: {
        name: companyInfo.CompanyName,
        id: realmId,
        country: companyInfo.Country,
      },
      next_steps: [
        'Your OAuth tokens are stored securely.',
        'The agent will auto-refresh tokens before they expire.',
        'You can now upload receipts via POST /api/receipts/upload',
        'Or configure email ingestion in your .env file.',
      ],
    });
  } catch (error) {
    logger.error('OAuth token exchange failed:', error);
    res.status(500).json({
      error: 'Connection failed',
      message: error.message,
      help: 'Verify your Client ID and Secret in .env, then try /api/auth/connect again.',
    });
  }
});

/**
 * GET /api/auth/status
 * Check current QuickBooks connection status
 */
router.get('/status', async (req, res) => {
  try {
    const connected = await qbService.isConnected();

    if (connected) {
      const companyInfo = await qbService.testConnection();
      res.json({
        connected: true,
        company: companyInfo.CompanyName,
        environment: process.env.QB_ENVIRONMENT || 'sandbox',
      });
    } else {
      res.json({
        connected: false,
        message: 'Not connected. Visit /api/auth/connect to authorize.',
      });
    }
  } catch (error) {
    res.json({
      connected: false,
      error: error.message,
    });
  }
});

/**
 * POST /api/auth/disconnect
 * Revoke tokens and disconnect from QuickBooks
 */
router.post('/disconnect', async (req, res) => {
  try {
    // TODO: Revoke token with Intuit's revoke endpoint
    const TokenStore = require('../utils/token-store');
    const store = new TokenStore();
    await store.clear();

    res.json({ success: true, message: 'Disconnected from QuickBooks.' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
