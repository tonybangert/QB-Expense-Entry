// src/routes/receipts.js
// Receipt upload and processing endpoints

const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { parseReceipt, parseReceiptPDF } = require('../services/receipt-parser');
const qbService = require('../services/quickbooks');
const logger = require('../utils/logger');

// Configure multer for receipt uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, '../../data/uploads');
    fs.mkdirSync(uploadDir, { recursive: true });
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const timestamp = Date.now();
    const ext = path.extname(file.originalname);
    cb(null, `receipt_${timestamp}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB max
  fileFilter: (req, file, cb) => {
    const allowed = [
      'image/jpeg', 'image/png', 'image/gif', 'image/webp',
      'image/heic', 'application/pdf',
    ];
    if (allowed.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error(`Unsupported file type: ${file.mimetype}`));
    }
  },
});

/**
 * POST /api/receipts/upload
 * Upload a receipt image for AI extraction
 * Returns extracted data for review before pushing to QB
 */
router.post('/upload', upload.single('receipt'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No receipt file uploaded' });
  }

  try {
    const imageBuffer = fs.readFileSync(req.file.path);
    const mimeType = req.file.mimetype;

    logger.info('Processing receipt upload', {
      filename: req.file.originalname,
      size: req.file.size,
      type: mimeType,
    });

    // Extract data using Claude Vision
    const extracted = mimeType === 'application/pdf'
      ? await parseReceiptPDF(imageBuffer)
      : await parseReceipt(imageBuffer, mimeType);

    // Store the extraction result with a reference ID
    const receiptId = `rcpt_${Date.now()}`;

    // TODO: Save to database instead of memory
    // For now, return the extraction for client-side review
    res.json({
      receipt_id: receiptId,
      status: 'extracted',
      file: {
        original_name: req.file.originalname,
        stored_path: req.file.path,
        size: req.file.size,
      },
      extraction: extracted,
      needs_review: extracted.overall_confidence < 0.85,
      actions: {
        approve: `POST /api/receipts/${receiptId}/approve`,
        reject: `POST /api/receipts/${receiptId}/reject`,
        edit: `PUT /api/receipts/${receiptId}`,
      },
    });
  } catch (error) {
    logger.error('Receipt processing failed:', error);
    res.status(500).json({
      error: 'Processing failed',
      message: error.message,
    });
  }
});

/**
 * POST /api/receipts/:id/approve
 * Approve extracted data and push to QuickBooks as an expense
 */
router.post('/:id/approve', async (req, res) => {
  const { id } = req.params;
  const overrides = req.body; // Allow field overrides at approval time

  try {
    // TODO: Load receipt from database by ID
    // For now, expect the full expense data in the request body
    const expenseData = {
      vendorName: overrides.vendor_name,
      date: overrides.date,
      totalAmount: overrides.total_amount,
      paymentMethod: overrides.payment_method || 'cash',
      lineItems: overrides.line_items || [],
      description: overrides.description || '',
    };

    // Create expense in QuickBooks
    const purchase = await qbService.createExpense(expenseData);

    res.json({
      success: true,
      receipt_id: id,
      quickbooks: {
        purchase_id: purchase.Id,
        total: purchase.TotalAmt,
        date: purchase.TxnDate,
      },
      message: 'Expense created in QuickBooks!',
    });
  } catch (error) {
    logger.error(`Failed to approve receipt ${id}:`, error);
    res.status(500).json({
      error: 'Failed to create expense in QuickBooks',
      message: error.message,
    });
  }
});

/**
 * POST /api/receipts/:id/reject
 * Reject a receipt (mark as skipped)
 */
router.post('/:id/reject', async (req, res) => {
  const { id } = req.params;
  const { reason } = req.body;

  // TODO: Update database record
  logger.info(`Receipt ${id} rejected: ${reason || 'No reason given'}`);

  res.json({
    success: true,
    receipt_id: id,
    status: 'rejected',
    reason: reason || 'No reason given',
  });
});

/**
 * GET /api/receipts/pending
 * List receipts awaiting review
 */
router.get('/pending', async (req, res) => {
  // TODO: Query database for pending receipts
  res.json({
    receipts: [],
    total: 0,
    message: 'Database not yet implemented — receipts are processed inline for now.',
  });
});

module.exports = router;
