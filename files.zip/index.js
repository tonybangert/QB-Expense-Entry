// src/index.js
// QB Expense Agent — Main server entry point

require('dotenv').config();

const express = require('express');
const cors = require('cors');
const path = require('path');
const logger = require('./utils/logger');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/receipts', require('./routes/receipts'));

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'QB Expense Agent',
    version: '0.1.0',
    environment: process.env.NODE_ENV || 'development',
  });
});

// Root — quick status page
app.get('/', async (req, res) => {
  const qbService = require('./services/quickbooks');
  const connected = await qbService.isConnected();

  res.json({
    name: 'QB Expense Agent — PerformanceLabs.AI',
    version: '0.1.0',
    quickbooks: {
      connected,
      environment: process.env.QB_ENVIRONMENT || 'sandbox',
      connect_url: connected ? null : '/api/auth/connect',
    },
    endpoints: {
      'GET  /api/auth/connect': 'Start QuickBooks OAuth flow',
      'GET  /api/auth/status': 'Check QB connection status',
      'POST /api/receipts/upload': 'Upload a receipt for processing',
      'POST /api/receipts/:id/approve': 'Approve and push to QB',
      'GET  /api/receipts/pending': 'List receipts awaiting review',
    },
  });
});

// Error handler
app.use((err, req, res, next) => {
  logger.error('Unhandled error:', err);
  res.status(500).json({
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development' ? err.message : undefined,
  });
});

app.listen(PORT, () => {
  logger.info(`QB Expense Agent running on port ${PORT}`);
  logger.info(`Environment: ${process.env.NODE_ENV || 'development'}`);
  logger.info(`QB Environment: ${process.env.QB_ENVIRONMENT || 'sandbox'}`);
  logger.info(`Visit http://localhost:${PORT} for status`);
});

module.exports = app;
